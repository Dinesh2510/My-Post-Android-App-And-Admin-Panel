
<?php include 'header.php';
include 'sidebar.php';


?>

        <!-- Begin Page Content -->
        <div class="container-fluid">
                    <h1 class="h3 mb-4 text-gray-800">Contact Page</h1>

 <div class="row">

            <!-- Earnings (Monthly) Card Example -->
          

            <!-- Earnings (Monthly) Card Example -->
           

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-lg-6 col-md-6 mb-6">
              <div class="card border-left-success shadow mb-4 py-3">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-success text-uppercase mb-1"> My Github</div>
                      <div class="row no-gutters align-items-center">
                        <div class="col-auto">
                         <a href="https://www.github.com/Dinesh2510" target="_blank" rel="nofollow"> <div class="h5 mb-0 mr-3 font-weight-bold success">Link: www.github.com/Dinesh2510</div></a>
                        </div>
                        
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fab fa-github fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-lg-6 col-md-6 mb-6">
              <div class="card border-left-info shadow mb-4 py-3">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
<div class="text-xs font-weight-bold text-info text-uppercase mb-1"> My Email</div>

                     <a href=""> <div class="text-xs font-weight-bold text-info text-uppercase mb-1"><b style="
                                font-size: medium;
                            ">Email: Dineshchavan7708@outlook.com</b></div></a>
                                                  
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-mail-bulk fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
</div>
            <!-- Pending Requests Card Example -->
         
          <!-- Page Heading -->
          <div class="col-lg-6 mb-4">

              <!-- Illustrations -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Android App</h6>
                </div>
                <div class="card-body">
                  <div class="text-center">
                    <img class="img-fluid px-3 px-sm-4 mt-3 mb-4" style="width: 25rem;" src="img/undraw_android.png" alt="">
                  </div>
                  <p>  My LEKH <a target="_blank" rel="nofollow" href="#">     </a></p>
                  <a target="_blank" rel="nofollow" href="#">Browse  &rarr;</a>
                </div>
              </div>
            </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
         <?php include 'footer.php'; ?>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.html">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

</body>

</html>
