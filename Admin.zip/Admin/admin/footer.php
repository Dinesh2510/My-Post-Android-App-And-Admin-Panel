 <footer class="sticky-footer bg-white">
        <div class="container my-auto">

          <div class="copyright text-center my-auto">
				 <?php  
				    $current_year=date('Y');
                echo "<span>Copyright &copy; My Post  $current_year</span>";
                ?>
          </div>

  <div style="padding: 10px;" class="copyright text-center my-auto">
				<b> Version 1.0</b>
          </div>
        </div>
      </footer>