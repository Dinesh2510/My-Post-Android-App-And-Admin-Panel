<?php

include "connection.php";

 $sql_select_banner="SELECT * FROM `post_banner`  WHERE  `flag`= '0' ORDER BY banner_id DESC";  
$result_select_banner=mysqli_query($conn,$sql_select_banner);

$result_count_banner=mysqli_num_rows($result_select_banner);


   
 $sql_select="SELECT * FROM `pc_posts`  WHERE  `disable_flag`= '0' ORDER BY post_id DESC";  
$result_select=mysqli_query($conn,$sql_select);

$result_count=mysqli_num_rows($result_select);

if($result_count>0)
{
    
if($result_count_banner>0)
{
while($row_banner=mysqli_fetch_array($result_select_banner))
{
$banner_id=$row_banner['banner_id'];
$banner_image=$row_banner['banner_image'];
          
$PostDetails_banner[]=array("banner_id" =>$banner_id,
                            "banner_image"=>$banner_image
                            );
}
}
while($row=mysqli_fetch_array($result_select))
{
    
        
    
            $post_id=$row['post_id'];
            $post_title=$row['post_title'];
            $post_description=$row['post_description'];
            $post_link=$row['post_link'];
            $post_image=$row['post_image'];
            $created_at=$row['created_at'];
            $category_id=$row['category_id'];
            $new_date = date("d-F-Y",strtotime($created_at));
            
$SELECT_TOPIC = "SELECT * FROM `pc_category` WHERE disable_flag = '0' AND category_id= '$category_id' ";
$RESULT_USER = mysqli_query($conn,$SELECT_TOPIC);
while ($ROW_TOPIC = mysqli_fetch_assoc($RESULT_USER)) {
$category_name = $ROW_TOPIC['category_name'];  
}
            $PostDetails[]=array(
                                "post_id" =>$post_id,
                                "post_title"=>$post_title,
                                "post_description" => $post_description,
                                "post_link" => $post_link,
                                "post_image" => $post_image,
                                "category_name" => $category_name,
                                "created_at"=>$new_date

                                );

}
$response=array("allPost"=> $PostDetails,"bannerList"=> $PostDetails_banner,"status"=>"ok" );
echo json_encode($response);
}
else
    {
        $response=array("response"=> "failure");
        echo json_encode($response);
    }

?>
