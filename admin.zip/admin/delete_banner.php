<?php
require_once('connection.php');
$passed_post_id=$_GET['post_id'];

$DeletePost="UPDATE `post_banner` SET `flag`= 1 WHERE banner_id= $passed_post_id";
$result = mysqli_query($conn,$DeletePost);




if ($result) {
   
 $response['status']  = 'success';
 $response['message'] = 'Banner Deleted Successfully ...';
     header('Location: list_of_banner.php');

    } else {
        $response['status']  = 'error';
 		$response['message'] = 'Something went wrong ...';
 		     header('Location: list_of_banner.php');

    }

    echo json_encode($response);
    
    
?>

 